public class StartingMenu {


    public void starter () {

        // Display of starter Game
        System.out.println("<<<Welcome to Guess The Number!>>>");
        System.out.println(" ");
        System.out.println("1.      Quick Play");
        System.out.println("2.  Double Guesser GM");
        System.out.println("3.        Rules");
        System.out.println("4.       Credits");
        System.out.println("5.         Exit ");
        System.out.println("-------------------");
        System.out.println(" ");


    }
}
