
public class Exit {
    StartingMenu sm = new StartingMenu();

    public void exit() {
        return;
    }
}
