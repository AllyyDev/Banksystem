public class DoubleG {

    public void game() {

    }
}
