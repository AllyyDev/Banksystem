public class Credits {
    private String name = "Ali Ayoub";

    public void credits() {
        System.out.println("Founded by " + name);
        System.out.println("Designed by " + name);
        System.out.println("Programmed by " + name);
        System.out.println("Language used: Java");
        System.out.println(" ");System.out.println(" ");
    }
}
